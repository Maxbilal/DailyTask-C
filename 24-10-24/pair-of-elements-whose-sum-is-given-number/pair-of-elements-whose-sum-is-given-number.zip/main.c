#include<stdio.h>

int main()
{
	int n,i,sum;
	printf("Enter the no of elements of array:");
	scanf("%d",&n);
	int a[n];
	for(i=0; i<n; i++)
	{
		scanf("%d",&a[i]);
	}
	printf("Enter the sum:");
	scanf("%d",&sum);
	
	printf("Pairs with %d are :",sum);
	int found=0;
	
	for(i=0;i<n;i++)
	{
	    for(int j=i+1;j<n;j++)
	    {
	        if(a[i]+a[j]==sum)
	        {
	            printf("%d,%d",a[i],a[j]);
	            found = 1;
	        }
	    }
	}
	if(!found)
	{
	    printf("No pair found\n");
	}
    
    return 0;
}
