/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int n,i;
	printf("Enter the Elements of the array :");
	scanf("%d",&n);
	int a1[n],a2[n];

	
	for (int i = 0; i < n; i++) {
		
		scanf("%d", &a1[i]);
	}
	for(i=0; i<n; i++)
	{
		a2[i] = a1[i];
	}
	printf("First Array ");
	for(i=0; i<n; i++)
	{
		printf("%d ",a1[i]);
	}
	printf("\n");
	printf("Second Array ");
	for(i=0; i<n; i++)
	{
		printf("%d ",a2[i]);
	}
	printf("\n");


	return 0;
}