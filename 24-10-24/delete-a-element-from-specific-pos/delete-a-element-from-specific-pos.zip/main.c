#include <stdio.h>

int main() {
	int n, pos, i;

	printf("Enter the no of elements in  array: ");
	scanf("%d", &n);
	int arr[n];
	for (i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
	}

	printf("Enter the element position to delete: ");
	scanf("%d", &pos);


	for (i = pos; i < n - 1; i++) {
		arr[i] = arr[i + 1];
	}
	n--;


	printf("Elements of array after delete: ");
	for (i = 0; i < n; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");

	return 0;
}